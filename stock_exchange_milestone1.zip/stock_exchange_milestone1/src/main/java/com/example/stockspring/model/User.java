package com.example.stockspring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="user")
public class User {
@Id
@Column(name="id")
private int id;
@NotEmpty(message="please enter username")
@Pattern(regexp="[a-z]{4,10}", message="Please enter 4-10 small case character")
@Column(name="username")
private String userName;
@NotEmpty(message="please enter password")
@Pattern(regexp="[a-z]{4,10}", message="Please enter 4-10 small case character")
@Column(name="password")
private String password;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getUserType() {
	return userType;
}
public void setUserType(String userType) {
	this.userType = userType;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public int getMobileNumber() {
	return mobileNumber;
}
public void setMobileNumber(int mobileNumber) {
	this.mobileNumber = mobileNumber;
}
@NotEmpty(message="please enter usertype")
@Pattern(regexp="[a-z]{4,10}", message="Please enter 4-10 small case character")
@Column(name="usertype")
private String userType;
@Email(message="please enter proper email")
@NotEmpty(message="please enter email")
@Column(name="email")
private String email;
@NotNull(message="please enter mobilenumber")
@Column(name="mobilenumber")
private int mobileNumber;

}
