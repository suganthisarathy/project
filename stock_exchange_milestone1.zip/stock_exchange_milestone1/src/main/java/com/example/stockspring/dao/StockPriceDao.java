package com.example.stockspring.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.stockspring.model.StockPriceDetails;

public interface StockPriceDao extends JpaRepository<StockPriceDetails, Integer>{

}
