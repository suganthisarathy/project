package com.example.stockspring.service;

import java.sql.SQLException;
import java.util.List;

import com.example.stockspring.model.IpoPlanned;

public interface IpoService {

	IpoPlanned insertIpo(IpoPlanned ipo) throws SQLException;

	IpoPlanned updateIpo(IpoPlanned ipo);

	List<IpoPlanned> getIpoList() throws Exception;

}
